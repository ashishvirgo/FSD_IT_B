import React from 'react'

const Header = () => {
  return (
    <div>
      <h1><center>ABESEC,GHAZIABAD</center></h1>
    </div>
  )
}

export default Header
